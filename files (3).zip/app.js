/* ===========================
   MI TARJETA — app.js v3
   =========================== */

const CATEGORIAS = [
  { nombre: 'Comida',             limite: 150,  icon: '🛒' },
  { nombre: 'Gasolina',           limite: 28,   icon: '⛽' },
  { nombre: 'Caprichos',          limite: 90,   icon: '✨' },
  { nombre: 'Piso',               limite: 355,  icon: '🏠' },
  { nombre: 'Gastos Fijos',       limite: 150,  icon: '📋' },
  { nombre: 'Restaurantes/Bares', limite: 80,   icon: '🍽️' },
  { nombre: 'Viajes',             limite: 300,  icon: '✈️' },
  { nombre: 'Otros',              limite: null, icon: '📦' },
];

const OBJETIVO_AHORRO = 200;
const PIN_DEFAULT = '1234';

const CAT_COLORS = {
  'Comida':              { fill: '#6366f1', border: '#818cf8' },
  'Gasolina':            { fill: '#0ea5e9', border: '#38bdf8' },
  'Caprichos':           { fill: '#f59e0b', border: '#fbbf24' },
  'Piso':                { fill: '#10b981', border: '#34d399' },
  'Gastos Fijos':        { fill: '#f43f5e', border: '#fb7185' },
  'Restaurantes/Bares':  { fill: '#a855f7', border: '#c084fc' },
  'Viajes':              { fill: '#06b6d4', border: '#22d3ee' },
  'Otros':               { fill: '#94a3b8', border: '#cbd5e1' },
};

// ── Estado ──────────────────────────────────────────────
let estado = cargarEstado();
let tipoActual = 'gasto';
let pinBuffer = '';

function estadoInicial() {
  return {
    movimientos: [],
    alertasEnviadas: {},
    historialMeses: [],   // [{mes, año, movimientos}]
    version: 2,
  };
}

function cargarEstado() {
  try {
    const raw = localStorage.getItem('mitarjeta_v2');
    if (raw) return JSON.parse(raw);
    // migrar v1
    const old = localStorage.getItem('mitarjeta_v1');
    if (old) {
      const parsed = JSON.parse(old);
      return { movimientos: parsed.movimientos || [], alertasEnviadas: {}, historialMeses: [], version: 2 };
    }
    return estadoInicial();
  } catch { return estadoInicial(); }
}

function guardarEstado() {
  localStorage.setItem('mitarjeta_v2', JSON.stringify(estado));
}

function getPin() {
  return localStorage.getItem('mitarjeta_pin') || PIN_DEFAULT;
}

// ── Utilidades ──────────────────────────────────────────
function fmt(n) {
  return n.toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
}

function fmtFecha(iso) {
  return new Date(iso).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function calcFechaNomina() {
  const hoy  = new Date();
  const año  = hoy.getMonth() === 11 ? hoy.getFullYear() + 1 : hoy.getFullYear();
  const mes  = (hoy.getMonth() + 1) % 12;
  let fecha  = new Date(año, mes + 1, 0);
  let habiles = 0;
  while (habiles < 4) {
    const dow = fecha.getDay();
    if (dow !== 0 && dow !== 6) habiles++;
    if (habiles < 4) fecha.setDate(fecha.getDate() - 1);
  }
  return fecha.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
}

// ── PIN ──────────────────────────────────────────────────
function pinPress(d) {
  if (pinBuffer.length >= 4) return;
  pinBuffer += d;
  updatePinDots();
  if (pinBuffer.length === 4) {
    setTimeout(() => checkPin(), 150);
  }
}

function pinDel() {
  pinBuffer = pinBuffer.slice(0, -1);
  updatePinDots();
}

function updatePinDots() {
  const dots = document.querySelectorAll('#pin-dots span');
  dots.forEach((d, i) => {
    d.classList.toggle('filled', i < pinBuffer.length);
  });
}

function checkPin() {
  if (pinBuffer === getPin()) {
    document.getElementById('pin-screen').style.display = 'none';
    document.getElementById('app').classList.remove('hidden');
    renderAll();
  } else {
    pinBuffer = '';
    updatePinDots();
    const sub = document.getElementById('pin-subtitle');
    sub.textContent = 'PIN incorrecto, inténtalo de nuevo';
    sub.style.color = '#f87171';
    setTimeout(() => { sub.textContent = 'Introduce tu PIN'; sub.style.color = ''; }, 1500);
  }
}

function mostrarCambiarPin() {
  document.getElementById('pin-screen').style.display = 'none';
  openModal('modal-pin');
}

function cambiarPin() {
  const oldPin = document.getElementById('pin-old').value;
  const newPin = document.getElementById('pin-new').value;
  if (oldPin !== getPin()) {
    mostrarToast('PIN actual incorrecto', 'error'); return;
  }
  if (!/^\d{4}$/.test(newPin)) {
    mostrarToast('El PIN debe tener 4 dígitos', 'info'); return;
  }
  localStorage.setItem('mitarjeta_pin', newPin);
  closeModal('modal-pin');
  document.getElementById('pin-screen').style.display = 'flex';
  pinBuffer = '';
  updatePinDots();
  mostrarToast('PIN actualizado', 'info');
}

// ── Notificaciones ──────────────────────────────────────
function mostrarToast(msg, tipo = 'error') {
  const container = document.getElementById('notif-container');
  const el = document.createElement('div');
  el.className = 'notif-toast' + (tipo === 'info' ? ' info' : '');
  el.innerHTML = '<div class="notif-dot"></div><span>' + msg + '</span>';
  container.prepend(el);
  setTimeout(() => el.remove(), 5000);
}

async function pedirPermisoNotificaciones() {
  if (!('Notification' in window)) return;
  if (Notification.permission === 'default') {
    const perm = await Notification.requestPermission();
    if (perm === 'granted') mostrarToast('Notificaciones activadas', 'info');
  }
}

function enviarNotificacion(titulo, cuerpo) {
  mostrarToast(titulo + ': ' + cuerpo);
  if ('Notification' in window && Notification.permission === 'granted') {
    new Notification(titulo, { body: cuerpo, icon: 'icons/icon-192.png' });
  }
}

// ── Cálculos ─────────────────────────────────────────────
function calcTotales() {
  const gastosPorCat = {};
  CATEGORIAS.forEach(c => gastosPorCat[c.nombre] = 0);
  let totalGastos = 0, totalIngresos = 0;
  estado.movimientos.forEach(m => {
    if (m.tipo === 'gasto') {
      gastosPorCat[m.categoria] = (gastosPorCat[m.categoria] || 0) + m.importe;
      totalGastos += m.importe;
    } else {
      totalIngresos += m.importe;
    }
  });
  return { gastosPorCat, totalGastos, totalIngresos, balance: totalIngresos - totalGastos };
}

// ── Render principal ─────────────────────────────────────
function renderAll() {
  const { gastosPorCat, totalGastos, totalIngresos, balance } = calcTotales();
  const ahorro = totalIngresos - totalGastos;

  const bEl = document.getElementById('balance-total');
  bEl.textContent = (balance >= 0 ? '+' : '') + fmt(balance);
  bEl.className = 'balance-amount ' + (balance >= 0 ? 'positive' : 'negative');
  document.getElementById('hdr-ingresos').textContent = fmt(totalIngresos);
  document.getElementById('hdr-gastos').textContent   = fmt(totalGastos);
  document.getElementById('hdr-ahorro').textContent   = fmt(Math.max(0, ahorro));

  // Objetivo ahorro
  const pctAhorro = Math.min(Math.max((ahorro / OBJETIVO_AHORRO) * 100, 0), 100);
  document.getElementById('ahorro-fill').style.width = Math.round(pctAhorro) + '%';
  document.getElementById('ahorro-fill').className   = 'ahorro-fill' + (pctAhorro >= 100 ? ' done' : pctAhorro >= 50 ? ' mid' : '');
  document.getElementById('ahorro-pct').textContent  = Math.round(pctAhorro) + '%';
  if (totalIngresos === 0) {
    document.getElementById('ahorro-status').textContent = 'Sin ingresos registrados';
  } else if (ahorro >= OBJETIVO_AHORRO) {
    document.getElementById('ahorro-status').textContent = '¡Objetivo alcanzado! +' + fmt(ahorro - OBJETIVO_AHORRO) + ' extra';
  } else if (ahorro > 0) {
    document.getElementById('ahorro-status').textContent = 'Faltan ' + fmt(OBJETIVO_AHORRO - ahorro) + ' para el objetivo';
  } else {
    document.getElementById('ahorro-status').textContent = 'Sin margen de ahorro este mes';
  }

  renderCategorias(gastosPorCat);
  renderIngresos();
  renderHistorial();
  if (document.getElementById('tab-graficas').classList.contains('active')) renderGraficas();
}

// ── Categorías con desglose ──────────────────────────────
function renderCategorias(gastosPorCat) {
  const list = document.getElementById('cat-list');
  list.innerHTML = '';

  CATEGORIAS.forEach(cat => {
    const gastado  = gastosPorCat[cat.nombre] || 0;
    const tieneLimit = cat.limite !== null;
    const pct      = tieneLimit ? Math.min((gastado / cat.limite) * 100, 100) : 0;
    const restante = tieneLimit ? cat.limite - gastado : null;
    const over     = tieneLimit && gastado > cat.limite;

    let fillCls = '';
    if (tieneLimit) {
      if (pct >= 100) fillCls = 'danger';
      else if (pct >= 75) fillCls = 'warn';
    }

    if (over && !estado.alertasEnviadas[cat.nombre]) {
      estado.alertasEnviadas[cat.nombre] = true;
      guardarEstado();
      enviarNotificacion('⚠️ Límite superado — ' + cat.nombre,
        'Llevas ' + fmt(gastado) + ' de ' + fmt(cat.limite) + ' (' + Math.round(pct) + '%)');
    } else if (!over) {
      estado.alertasEnviadas[cat.nombre] = false;
    }

    const movsCat = estado.movimientos.filter(m => m.tipo === 'gasto' && m.categoria === cat.nombre);
    const numMovs = movsCat.length;

    const card = document.createElement('div');
    card.className = 'cat-card' + (over ? ' over' : '');
    card.style.cursor = 'pointer';
    card.innerHTML =
      '<div class="cat-header">' +
        '<div class="cat-left">' +
          '<div class="cat-emoji">' + cat.icon + '</div>' +
          '<div>' +
            '<div class="cat-name">' + cat.nombre + '</div>' +
            '<div class="cat-sub">' + (tieneLimit ? 'Límite: ' + fmt(cat.limite) : 'Sin límite') + ' &middot; ' + numMovs + ' movimiento' + (numMovs !== 1 ? 's' : '') + '</div>' +
          '</div>' +
        '</div>' +
        '<div class="cat-amounts">' +
          '<div class="cat-spent">' + fmt(gastado) + '</div>' +
          '<div class="cat-limit cat-chevron">' + (tieneLimit ? Math.round(pct) + '% usado' : '') + ' ›</div>' +
        '</div>' +
      '</div>' +
      (tieneLimit ?
        '<div class="progress-track"><div class="progress-fill ' + fillCls + '" style="width:' + Math.round(pct) + '%"></div></div>' +
        '<div class="cat-footer">' +
          '<span>' + (over ? '⚠️ Superado en ' + fmt(-restante) : 'Disponible: ' + fmt(restante)) + '</span>' +
          (over ? '<span class="badge-over">Límite superado</span>' : pct >= 75 ? '<span style="font-size:11px;color:#fbbf24">⚠️ Casi al límite</span>' : '<span class="badge-ok">OK</span>') +
        '</div>'
      : '<div class="cat-footer"><span style="color:var(--text3)">Categoría sin límite</span></div>');

    card.addEventListener('click', () => abrirDesglose(cat.nombre));
    list.appendChild(card);
  });
}

function abrirDesglose(catNombre) {
  const cat    = CATEGORIAS.find(c => c.nombre === catNombre);
  const movs   = estado.movimientos.filter(m => m.tipo === 'gasto' && m.categoria === catNombre);
  const total  = movs.reduce((s, m) => s + m.importe, 0);
  const tieneLimit = cat.limite !== null;

  document.getElementById('desglose-titulo').textContent = cat.icon + ' ' + catNombre;

  document.getElementById('desglose-resumen').innerHTML =
    '<div class="desglose-stats">' +
      '<div class="dstat"><div class="dstat-val">' + fmt(total) + '</div><div class="dstat-lbl">Total gastado</div></div>' +
      (tieneLimit ? '<div class="dstat"><div class="dstat-val">' + fmt(cat.limite) + '</div><div class="dstat-lbl">Presupuesto</div></div>' : '') +
      (tieneLimit ? '<div class="dstat"><div class="dstat-val ' + (total > cat.limite ? 'red' : 'green') + '">' + fmt(cat.limite - total) + '</div><div class="dstat-lbl">' + (total > cat.limite ? 'Excedido' : 'Disponible') + '</div></div>' : '') +
      '<div class="dstat"><div class="dstat-val">' + movs.length + '</div><div class="dstat-lbl">Movimientos</div></div>' +
    '</div>';

  const lista = document.getElementById('desglose-lista');
  if (movs.length === 0) {
    lista.innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><div>Sin gastos en esta categoría</div></div>';
  } else {
    lista.innerHTML = '<div class="section-header">Todos los gastos</div>' +
      movs.slice().reverse().map(m =>
        '<div class="historial-item">' +
          '<div class="mov-left">' +
            '<div class="mov-icon">' + cat.icon + '</div>' +
            '<div>' +
              '<div class="mov-name">' + (m.desc || catNombre) + '</div>' +
              '<div class="mov-cat">' + fmtFecha(m.fecha) + '</div>' +
            '</div>' +
          '</div>' +
          '<div class="mov-amount neg">-' + fmt(m.importe) + '</div>' +
        '</div>'
      ).join('');
  }

  openModal('modal-desglose');
}

// ── Ingresos ─────────────────────────────────────────────
function renderIngresos() {
  const ingresos = estado.movimientos.filter(m => m.tipo === 'ingreso');
  const list     = document.getElementById('ingresos-list');
  const empty    = document.getElementById('ingresos-empty');
  list.innerHTML = '';
  if (ingresos.length === 0) { empty.classList.remove('hidden'); return; }
  empty.classList.add('hidden');
  ingresos.slice().reverse().forEach(m => {
    const el = document.createElement('div');
    el.className = 'ingreso-item';
    el.innerHTML =
      '<div class="mov-left"><div class="mov-icon ing">💰</div><div>' +
      '<div class="mov-name">' + (m.desc || 'Ingreso') + '</div>' +
      '<div class="mov-cat">' + fmtFecha(m.fecha) + '</div></div></div>' +
      '<div class="mov-amount pos">+' + fmt(m.importe) + '</div>';
    list.appendChild(el);
  });
}

// ── Historial ────────────────────────────────────────────
function renderHistorial() {
  const list  = document.getElementById('historial-list');
  const empty = document.getElementById('historial-empty');
  list.innerHTML = '';
  const todos = estado.movimientos.slice().reverse();
  if (todos.length === 0) { empty.classList.remove('hidden'); return; }
  empty.classList.add('hidden');
  todos.forEach(m => {
    const cat = CATEGORIAS.find(c => c.nombre === m.categoria);
    const el  = document.createElement('div');
    el.className = 'historial-item';
    el.innerHTML =
      '<div class="mov-left"><div class="mov-icon">' + (m.tipo === 'ingreso' ? '💰' : (cat ? cat.icon : '💳')) + '</div><div>' +
      '<div class="mov-name">' + (m.desc || (m.tipo === 'ingreso' ? 'Ingreso' : m.categoria)) + '</div>' +
      '<div class="mov-cat">' + (m.tipo === 'gasto' ? m.categoria + ' · ' : '') + fmtFecha(m.fecha) + '</div></div></div>' +
      '<div class="mov-amount ' + (m.tipo === 'ingreso' ? 'pos' : 'neg') + '">' +
      (m.tipo === 'ingreso' ? '+' : '-') + fmt(m.importe) + '</div>';
    list.appendChild(el);
  });
}

// ── Gráficas ─────────────────────────────────────────────
let chartDonut = null, chartBarras = null, chartMeses = null, chartLinea = null;

function renderGraficas() {
  const { gastosPorCat, totalGastos } = calcTotales();
  const gastos = estado.movimientos.filter(m => m.tipo === 'gasto');

  // 1. CIRCULAR
  const donutCanvas = document.getElementById('chart-donut');
  const donutEmpty  = document.getElementById('graficas-empty1');
  if (totalGastos === 0) {
    donutCanvas.style.display = 'none';
    document.getElementById('donut-legend').style.display = 'none';
    document.getElementById('donut-center').style.display = 'none';
    donutEmpty.classList.remove('hidden');
  } else {
    donutCanvas.style.display = 'block';
    document.getElementById('donut-legend').style.display = 'flex';
    document.getElementById('donut-center').style.display = 'block';
    donutEmpty.classList.add('hidden');

    const catsConGasto = CATEGORIAS.filter(c => (gastosPorCat[c.nombre] || 0) > 0);
    document.getElementById('donut-center').innerHTML =
      '<span class="dc-amount">' + fmt(totalGastos) + '</span><span class="dc-label">total gastado</span>';

    document.getElementById('donut-legend').innerHTML = catsConGasto.map(c => {
      const g = gastosPorCat[c.nombre] || 0;
      const pct = Math.round((g / totalGastos) * 100);
      return '<div class="legend-item">' +
        '<div class="legend-left"><div class="legend-dot" style="background:' + CAT_COLORS[c.nombre].fill + '"></div>' +
        '<span class="legend-name">' + c.icon + ' ' + c.nombre + '</span></div>' +
        '<div style="display:flex;gap:12px;align-items:center">' +
        '<span class="legend-amt">' + fmt(g) + '</span>' +
        '<span class="legend-pct">' + pct + '%</span></div></div>';
    }).join('');

    if (chartDonut) chartDonut.destroy();
    chartDonut = new Chart(donutCanvas, {
      type: 'doughnut',
      data: {
        labels: catsConGasto.map(c => c.nombre),
        datasets: [{
          data: catsConGasto.map(c => Math.round((gastosPorCat[c.nombre] || 0) * 100) / 100),
          backgroundColor: catsConGasto.map(c => CAT_COLORS[c.nombre].fill),
          borderColor: catsConGasto.map(c => CAT_COLORS[c.nombre].border),
          borderWidth: 2, hoverOffset: 8
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '68%',
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: ctx => ' ' + fmt(ctx.raw) + '  (' + Math.round((ctx.raw / totalGastos) * 100) + '%)' } }
        }
      }
    });
  }

  // 2. PRESUPUESTO VS GASTO REAL
  const barCanvas = document.getElementById('chart-barras');
  const barEmpty  = document.getElementById('graficas-empty2');
  const catsConLimite = CATEGORIAS.filter(c => c.limite !== null);
  if (totalGastos === 0) {
    barCanvas.style.display = 'none'; barEmpty.classList.remove('hidden');
  } else {
    barCanvas.style.display = 'block'; barEmpty.classList.add('hidden');
    const barFills = catsConLimite.map(c => {
      const g = gastosPorCat[c.nombre] || 0;
      const p = g / c.limite;
      return p >= 1 ? '#f43f5e' : p >= 0.75 ? '#f59e0b' : CAT_COLORS[c.nombre].fill;
    });
    if (chartBarras) chartBarras.destroy();
    chartBarras = new Chart(barCanvas, {
      type: 'bar',
      data: {
        labels: catsConLimite.map(c => c.nombre),
        datasets: [
          { label: 'Presupuesto', data: catsConLimite.map(c => c.limite), backgroundColor: 'rgba(255,255,255,0.07)', borderColor: 'rgba(255,255,255,0.2)', borderWidth: 1, borderRadius: 6, borderSkipped: false, order: 2 },
          { label: 'Gastado', data: catsConLimite.map(c => Math.round((gastosPorCat[c.nombre] || 0) * 100) / 100), backgroundColor: barFills, borderRadius: 6, borderSkipped: false, order: 1 }
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ' ' + ctx.dataset.label + ': ' + fmt(ctx.raw) } } },
        scales: {
          x: { ticks: { color: '#64748b', font: { size: 10 }, maxRotation: 35 }, grid: { display: false }, border: { display: false } },
          y: { ticks: { color: '#64748b', font: { size: 11 }, callback: v => v + ' €' }, grid: { color: 'rgba(255,255,255,0.05)' }, border: { display: false } }
        }
      }
    });
  }

  // 3. EVOLUCIÓN MES A MES
  const mesesCanvas = document.getElementById('chart-meses');
  const mesesEmpty  = document.getElementById('graficas-empty3');
  const histMeses   = estado.historialMeses || [];
  const { totalGastos: gastosMesActual, totalIngresos: ingresosMesActual } = calcTotales();
  const mesActualLabel = new Date().toLocaleDateString('es-ES', { month: 'short', year: '2-digit' });

  if (histMeses.length === 0) {
    mesesCanvas.style.display = 'none'; mesesEmpty.classList.remove('hidden');
  } else {
    mesesCanvas.style.display = 'block'; mesesEmpty.classList.add('hidden');
    const allMeses  = [...histMeses, { label: mesActualLabel, totalGastos: gastosMesActual, totalIngresos: ingresosMesActual }];
    if (chartMeses) chartMeses.destroy();
    chartMeses = new Chart(mesesCanvas, {
      type: 'line',
      data: {
        labels: allMeses.map(m => m.label),
        datasets: [
          { label: 'Gastos', data: allMeses.map(m => Math.round(m.totalGastos * 100) / 100), borderColor: '#f43f5e', backgroundColor: 'rgba(244,63,94,0.1)', borderWidth: 2.5, pointBackgroundColor: '#f43f5e', pointRadius: 4, fill: true, tension: 0.35 },
          { label: 'Ingresos', data: allMeses.map(m => Math.round(m.totalIngresos * 100) / 100), borderColor: '#4ade80', backgroundColor: 'rgba(74,222,128,0.08)', borderWidth: 2.5, pointBackgroundColor: '#4ade80', pointRadius: 4, fill: true, tension: 0.35 }
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ' ' + ctx.dataset.label + ': ' + fmt(ctx.raw) } } },
        scales: {
          x: { ticks: { color: '#64748b', font: { size: 11 } }, grid: { display: false }, border: { display: false } },
          y: { ticks: { color: '#64748b', font: { size: 11 }, callback: v => v + ' €' }, grid: { color: 'rgba(255,255,255,0.05)' }, border: { display: false } }
        }
      }
    });
  }

  // 4. EVOLUCIÓN DIARIA
  const lineCanvas = document.getElementById('chart-linea');
  const lineEmpty  = document.getElementById('graficas-empty4');
  if (gastos.length === 0) {
    lineCanvas.style.display = 'none'; lineEmpty.classList.remove('hidden');
  } else {
    lineCanvas.style.display = 'block'; lineEmpty.classList.add('hidden');
    const porDia = {};
    gastos.forEach(m => {
      const dia = new Date(m.fecha).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
      porDia[dia] = (porDia[dia] || 0) + m.importe;
    });
    const diasOrdenados = gastos
      .map(m => ({ key: new Date(m.fecha).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' }), ts: new Date(m.fecha).getTime() }))
      .sort((a, b) => a.ts - b.ts).map(x => x.key)
      .filter((v, i, arr) => arr.indexOf(v) === i);
    let acum = 0;
    const lineData = diasOrdenados.map(d => { acum += porDia[d]; return Math.round(acum * 100) / 100; });
    if (chartLinea) chartLinea.destroy();
    chartLinea = new Chart(lineCanvas, {
      type: 'line',
      data: {
        labels: diasOrdenados,
        datasets: [{ label: 'Gasto acumulado', data: lineData, borderColor: '#6366f1', backgroundColor: 'rgba(99,102,241,0.12)', borderWidth: 2.5, pointBackgroundColor: '#6366f1', pointRadius: 4, pointHoverRadius: 6, fill: true, tension: 0.35 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ' ' + fmt(ctx.raw) + ' acumulado' } } },
        scales: {
          x: { ticks: { color: '#64748b', font: { size: 11 }, maxRotation: 30, autoSkip: true, maxTicksLimit: 8 }, grid: { display: false }, border: { display: false } },
          y: { ticks: { color: '#64748b', font: { size: 11 }, callback: v => v + ' €' }, grid: { color: 'rgba(255,255,255,0.05)' }, border: { display: false } }
        }
      }
    });
  }
}

// ── Exportar Excel ────────────────────────────────────────
function exportarExcel() {
  if (!window.XLSX) { mostrarToast('Librería Excel no cargada', 'error'); return; }
  const wb   = XLSX.utils.book_new();
  const mes  = new Date().toLocaleDateString('es-ES', { month: 'long', year: 'numeric' });

  // Hoja movimientos
  const movRows = [['Fecha', 'Tipo', 'Categoría', 'Descripción', 'Importe (€)']];
  estado.movimientos.forEach(m => {
    movRows.push([
      new Date(m.fecha).toLocaleDateString('es-ES'),
      m.tipo === 'gasto' ? 'Gasto' : 'Ingreso',
      m.categoria || '—',
      m.desc || '—',
      m.importe
    ]);
  });
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(movRows), 'Movimientos');

  // Hoja resumen por categoría
  const { gastosPorCat, totalGastos, totalIngresos } = calcTotales();
  const resRows = [['Categoría', 'Presupuesto (€)', 'Gastado (€)', 'Diferencia (€)', '% Usado']];
  CATEGORIAS.forEach(c => {
    const g = gastosPorCat[c.nombre] || 0;
    resRows.push([
      c.nombre,
      c.limite || 'Sin límite',
      Math.round(g * 100) / 100,
      c.limite ? Math.round((c.limite - g) * 100) / 100 : '—',
      c.limite ? Math.round((g / c.limite) * 100) + '%' : '—'
    ]);
  });
  resRows.push(['']);
  resRows.push(['TOTAL INGRESOS', '', Math.round(totalIngresos * 100) / 100]);
  resRows.push(['TOTAL GASTOS',   '', Math.round(totalGastos * 100) / 100]);
  resRows.push(['BALANCE',        '', Math.round((totalIngresos - totalGastos) * 100) / 100]);
  resRows.push(['AHORRO OBJETIVO', 200, '', '', (totalIngresos - totalGastos) >= 200 ? '✓ Conseguido' : '✗ No alcanzado']);
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(resRows), 'Resumen');

  XLSX.writeFile(wb, 'MiTarjeta_' + mes.replace(' ', '_') + '.xlsx');
  mostrarToast('Excel exportado correctamente', 'info');
}

// ── Modals ───────────────────────────────────────────────
function openModal(id) {
  document.getElementById(id).classList.remove('hidden');
  document.getElementById(id).style.display = 'flex';
}
function closeModal(id) {
  document.getElementById(id).style.display = 'none';
}
function closeModalOutside(e, id) {
  if (e.target === document.getElementById(id)) closeModal(id);
}
function setTipo(t) {
  tipoActual = t;
  document.getElementById('btn-gasto').classList.toggle('active', t === 'gasto');
  document.getElementById('btn-ingreso').classList.toggle('active', t === 'ingreso');
  document.getElementById('fg-cat').style.display = t === 'gasto' ? '' : 'none';
}

// ── Guardar movimiento ───────────────────────────────────
function guardarMovimiento() {
  const desc    = document.getElementById('inp-desc').value.trim();
  const importe = parseFloat(document.getElementById('inp-imp').value);
  if (!importe || importe <= 0) { mostrarToast('Introduce un importe válido', 'info'); return; }
  const mov = {
    id:        Date.now(),
    tipo:      tipoActual,
    categoria: tipoActual === 'gasto' ? document.getElementById('inp-cat').value : null,
    desc:      desc || null,
    importe,
    fecha:     new Date().toISOString(),
  };
  estado.movimientos.push(mov);
  guardarEstado();
  document.getElementById('inp-desc').value = '';
  document.getElementById('inp-imp').value  = '';
  closeModal('modal-add');
  renderAll();
  switchTab(tipoActual === 'gasto' ? 'gastos' : 'ingresos');
}

// ── Reset / cerrar mes ───────────────────────────────────
function resetMes() {
  const { totalGastos, totalIngresos } = calcTotales();
  const label = new Date().toLocaleDateString('es-ES', { month: 'short', year: '2-digit' });
  estado.historialMeses = estado.historialMeses || [];
  estado.historialMeses.push({ label, totalGastos, totalIngresos });
  estado.movimientos    = [];
  estado.alertasEnviadas = {};
  guardarEstado();
  closeModal('modal-reset');
  renderAll();
  mostrarToast('Mes cerrado y archivado', 'info');
}

// ── Tabs ─────────────────────────────────────────────────
function switchTab(nombre) {
  document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
  document.getElementById('tab-' + nombre).classList.add('active');
  document.querySelector('[data-tab="' + nombre + '"]').classList.add('active');
  if (nombre === 'graficas') renderGraficas();
}

// ── Init ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('fecha-hoy').textContent =
    new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
  document.getElementById('fecha-nomina').textContent = calcFechaNomina();
  pedirPermisoNotificaciones();

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
});
