/* ===========================
   MI TARJETA — app.js
   =========================== */

const CATEGORIAS = [
  { nombre: 'Comida',            limite: 150,  icon: '🛒' },
  { nombre: 'Gasolina',          limite: 28,   icon: '⛽' },
  { nombre: 'Caprichos',         limite: 90,   icon: '✨' },
  { nombre: 'Piso',              limite: 355,  icon: '🏠' },
  { nombre: 'Gastos Fijos',      limite: 150,  icon: '📋' },
  { nombre: 'Restaurantes/Bares', limite: 80,  icon: '🍽️' },
];

// ── Estado ──────────────────────────────────────────────
let estado = cargarEstado();
let tipoActual = 'gasto';

function estadoInicial() {
  return {
    movimientos: [],      // { id, tipo, categoria, desc, importe, fecha }
    alertasEnviadas: {},  // { categoria: true/false }
    version: 1,
  };
}

function cargarEstado() {
  try {
    const raw = localStorage.getItem('mitarjeta_v1');
    return raw ? JSON.parse(raw) : estadoInicial();
  } catch { return estadoInicial(); }
}

function guardarEstado() {
  localStorage.setItem('mitarjeta_v1', JSON.stringify(estado));
}

// ── Utilidades ──────────────────────────────────────────
function fmt(n) {
  return n.toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
}

function fmtFecha(iso) {
  return new Date(iso).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function calcFechaNomina() {
  const hoy = new Date();
  const año  = hoy.getMonth() === 11 ? hoy.getFullYear() + 1 : hoy.getFullYear();
  const mes  = (hoy.getMonth() + 1) % 12;
  let fecha  = new Date(año, mes + 1, 0); // último día del mes siguiente
  let habiles = 0;
  while (habiles < 4) {
    const dow = fecha.getDay();
    if (dow !== 0 && dow !== 6) habiles++;
    if (habiles < 4) fecha.setDate(fecha.getDate() - 1);
  }
  return fecha.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
}

// ── Notificaciones ──────────────────────────────────────
function mostrarToast(msg, tipo = 'error') {
  const container = document.getElementById('notif-container');
  const el = document.createElement('div');
  el.className = 'notif-toast' + (tipo === 'info' ? ' info' : '');
  el.innerHTML = `<div class="notif-dot"></div><span>${msg}</span>`;
  container.prepend(el);
  setTimeout(() => el.remove(), 5000);
}

async function pedirPermisoNotificaciones() {
  if (!('Notification' in window)) return;
  if (Notification.permission === 'default') {
    const perm = await Notification.requestPermission();
    if (perm === 'granted') mostrarToast('Notificaciones activadas', 'info');
  }
}

function enviarNotificacion(titulo, cuerpo) {
  // Toast siempre
  mostrarToast(`${titulo}: ${cuerpo}`);

  // Notificación del sistema si hay permiso
  if ('Notification' in window && Notification.permission === 'granted') {
    new Notification(titulo, {
      body: cuerpo,
      icon: 'icons/icon-192.png',
      badge: 'icons/icon-192.png',
    });
  }
}

// ── Cálculos ─────────────────────────────────────────────
function calcTotales() {
  const gastosPorCat = {};
  CATEGORIAS.forEach(c => gastosPorCat[c.nombre] = 0);

  let totalGastos   = 0;
  let totalIngresos = 0;

  estado.movimientos.forEach(m => {
    if (m.tipo === 'gasto') {
      gastosPorCat[m.categoria] = (gastosPorCat[m.categoria] || 0) + m.importe;
      totalGastos += m.importe;
    } else {
      totalIngresos += m.importe;
    }
  });

  return { gastosPorCat, totalGastos, totalIngresos, balance: totalIngresos - totalGastos };
}

// ── Render ───────────────────────────────────────────────
function renderAll() {
  const { gastosPorCat, totalGastos, totalIngresos, balance } = calcTotales();

  // Header
  const bEl = document.getElementById('balance-total');
  bEl.textContent = (balance >= 0 ? '+' : '') + fmt(balance);
  bEl.className   = 'balance-amount ' + (balance >= 0 ? 'positive' : 'negative');
  document.getElementById('hdr-ingresos').textContent = fmt(totalIngresos);
  document.getElementById('hdr-gastos').textContent   = fmt(totalGastos);

  renderCategorias(gastosPorCat);
  renderIngresos();
  renderHistorial();

  // Sólo renderizar gráficas si la pestaña está visible (para no inicializar canvas ocultos)
  if (document.getElementById('tab-graficas').classList.contains('active')) {
    renderGraficas();
  }
}

function renderCategorias(gastosPorCat) {
  const list = document.getElementById('cat-list');
  list.innerHTML = '';

  CATEGORIAS.forEach(cat => {
    const gastado  = gastosPorCat[cat.nombre] || 0;
    const pct      = Math.min((gastado / cat.limite) * 100, 100);
    const restante = cat.limite - gastado;
    const over     = gastado > cat.limite;

    let fillCls = '';
    if (pct >= 100) fillCls = 'danger';
    else if (pct >= 75) fillCls = 'warn';

    // Alerta automática
    if (over && !estado.alertasEnviadas[cat.nombre]) {
      estado.alertasEnviadas[cat.nombre] = true;
      guardarEstado();
      enviarNotificacion(
        `⚠️ Límite superado — ${cat.nombre}`,
        `Llevas ${fmt(gastado)} de ${fmt(cat.limite)} (${Math.round(pct)}%)`
      );
    } else if (!over) {
      estado.alertasEnviadas[cat.nombre] = false;
    }

    const card = document.createElement('div');
    card.className = 'cat-card' + (over ? ' over' : '');
    card.innerHTML = `
      <div class="cat-header">
        <div class="cat-left">
          <div class="cat-emoji">${cat.icon}</div>
          <div>
            <div class="cat-name">${cat.nombre}</div>
            <div class="cat-sub">Límite: ${fmt(cat.limite)}</div>
          </div>
        </div>
        <div class="cat-amounts">
          <div class="cat-spent">${fmt(gastado)}</div>
          <div class="cat-limit">${Math.round(pct)}% usado</div>
        </div>
      </div>
      <div class="progress-track">
        <div class="progress-fill ${fillCls}" style="width:${pct}%"></div>
      </div>
      <div class="cat-footer">
        <span>${over ? '⚠️ Superado en ' + fmt(-restante) : 'Disponible: ' + fmt(restante)}</span>
        ${over ? '<span class="badge-over">Límite superado</span>' : pct >= 75 ? '<span style="font-size:11px;color:var(--amber)">⚠️ Casi al límite</span>' : '<span class="badge-ok">OK</span>'}
      </div>`;
    list.appendChild(card);
  });
}

function renderIngresos() {
  const ingresos = estado.movimientos.filter(m => m.tipo === 'ingreso');
  const list = document.getElementById('ingresos-list');
  const empty = document.getElementById('ingresos-empty');

  list.innerHTML = '';
  if (ingresos.length === 0) { empty.classList.remove('hidden'); return; }
  empty.classList.add('hidden');

  ingresos.slice().reverse().forEach(m => {
    const el = document.createElement('div');
    el.className = 'ingreso-item';
    el.innerHTML = `
      <div class="mov-left">
        <div class="mov-icon ing">💰</div>
        <div>
          <div class="mov-name">${m.desc || 'Ingreso'}</div>
          <div class="mov-cat">${fmtFecha(m.fecha)}</div>
        </div>
      </div>
      <div class="mov-amount pos">+${fmt(m.importe)}</div>`;
    list.appendChild(el);
  });
}

function renderHistorial() {
  const list  = document.getElementById('historial-list');
  const empty = document.getElementById('historial-empty');
  list.innerHTML = '';

  const todos = estado.movimientos.slice().reverse();
  if (todos.length === 0) { empty.classList.remove('hidden'); return; }
  empty.classList.add('hidden');

  todos.forEach(m => {
    const cat = CATEGORIAS.find(c => c.nombre === m.categoria);
    const el  = document.createElement('div');
    el.className = 'historial-item';
    el.innerHTML = `
      <div class="mov-left">
        <div class="mov-icon">${m.tipo === 'ingreso' ? '💰' : (cat ? cat.icon : '💳')}</div>
        <div>
          <div class="mov-name">${m.desc || (m.tipo === 'ingreso' ? 'Ingreso' : m.categoria)}</div>
          <div class="mov-cat">${m.tipo === 'gasto' ? m.categoria + ' · ' : ''}${fmtFecha(m.fecha)}</div>
        </div>
      </div>
      <div class="mov-amount ${m.tipo === 'ingreso' ? 'pos' : 'neg'}">
        ${m.tipo === 'ingreso' ? '+' : '-'}${fmt(m.importe)}
      </div>`;
    list.appendChild(el);
  });
}

// ── Gráficas ─────────────────────────────────────────────

// Colores para cada categoría (hardcoded para Chart.js, no puede usar CSS vars)
const CAT_COLORS = {
  'Comida':              { fill: '#6366f1', border: '#818cf8' },
  'Gasolina':            { fill: '#0ea5e9', border: '#38bdf8' },
  'Caprichos':           { fill: '#f59e0b', border: '#fbbf24' },
  'Piso':                { fill: '#10b981', border: '#34d399' },
  'Gastos Fijos':        { fill: '#f43f5e', border: '#fb7185' },
  'Restaurantes/Bares':  { fill: '#a855f7', border: '#c084fc' },
};

let chartDonut  = null;
let chartBarras = null;
let chartLinea  = null;

function renderGraficas() {
  const { gastosPorCat, totalGastos } = calcTotales();
  const gastos = estado.movimientos.filter(m => m.tipo === 'gasto');

  const tieneGastos = totalGastos > 0;

  // ─ 1. Donut: distribución ─
  const donutCanvas = document.getElementById('chart-donut');
  const donutEmpty  = document.getElementById('graficas-empty1');
  const donutLegend = document.getElementById('donut-legend');
  const donutCenter = document.getElementById('donut-center');

  if (!tieneGastos) {
    donutCanvas.style.display = 'none';
    donutLegend.style.display = 'none';
    donutCenter.style.display = 'none';
    donutEmpty.classList.remove('hidden');
  } else {
    donutCanvas.style.display = 'block';
    donutLegend.style.display = 'flex';
    donutCenter.style.display = 'block';
    donutEmpty.classList.add('hidden');

    const labels  = CATEGORIAS.map(c => c.nombre);
    const data    = CATEGORIAS.map(c => Math.round((gastosPorCat[c.nombre] || 0) * 100) / 100);
    const fills   = CATEGORIAS.map(c => CAT_COLORS[c.nombre].fill);
    const borders = CATEGORIAS.map(c => CAT_COLORS[c.nombre].border);

    donutCenter.innerHTML = `
      <span class="dc-amount">${fmt(totalGastos)}</span>
      <span class="dc-label">total gastado</span>`;

    donutLegend.innerHTML = CATEGORIAS.map(c => {
      const g   = gastosPorCat[c.nombre] || 0;
      const pct = totalGastos > 0 ? Math.round((g / totalGastos) * 100) : 0;
      const col = CAT_COLORS[c.nombre].fill;
      return `<div class="legend-item">
        <div class="legend-left">
          <div class="legend-dot" style="background:${col}"></div>
          <span class="legend-name">${c.icon} ${c.nombre}</span>
        </div>
        <div style="display:flex;gap:12px;align-items:center">
          <span class="legend-amt">${fmt(g)}</span>
          <span class="legend-pct">${pct}%</span>
        </div>
      </div>`;
    }).join('');

    if (chartDonut) chartDonut.destroy();
    chartDonut = new Chart(donutCanvas, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{ data, backgroundColor: fills, borderColor: borders, borderWidth: 2, hoverOffset: 6 }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => ` ${fmt(ctx.raw)}  (${Math.round((ctx.raw / totalGastos) * 100)}%)`
            }
          }
        }
      }
    });
  }

  // ─ 2. Barras: gasto vs límite ─
  const barCanvas = document.getElementById('chart-barras');
  const barEmpty  = document.getElementById('graficas-empty2');

  if (!tieneGastos) {
    barCanvas.style.display = 'none';
    barEmpty.classList.remove('hidden');
  } else {
    barCanvas.style.display = 'block';
    barEmpty.classList.add('hidden');

    const gastadoData = CATEGORIAS.map(c => Math.round((gastosPorCat[c.nombre] || 0) * 100) / 100);
    const limiteData  = CATEGORIAS.map(c => c.limite);
    const barFills    = CATEGORIAS.map(c => {
      const g = gastosPorCat[c.nombre] || 0;
      const p = g / c.limite;
      if (p >= 1)    return '#f43f5e';
      if (p >= 0.75) return '#f59e0b';
      return CAT_COLORS[c.nombre].fill;
    });

    if (chartBarras) chartBarras.destroy();
    chartBarras = new Chart(barCanvas, {
      type: 'bar',
      data: {
        labels: CATEGORIAS.map(c => c.nombre),
        datasets: [
          {
            label: 'Gastado',
            data: gastadoData,
            backgroundColor: barFills,
            borderRadius: 6,
            borderSkipped: false,
            order: 1,
          },
          {
            label: 'Límite',
            data: limiteData,
            backgroundColor: 'rgba(255,255,255,0.06)',
            borderColor: 'rgba(255,255,255,0.18)',
            borderWidth: 1,
            borderRadius: 6,
            borderSkipped: false,
            order: 2,
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => ` ${ctx.dataset.label}: ${fmt(ctx.raw)}`
            }
          }
        },
        scales: {
          x: {
            ticks: { color: '#64748b', font: { size: 11 }, maxRotation: 30 },
            grid:  { display: false },
            border: { display: false },
          },
          y: {
            ticks: { color: '#64748b', font: { size: 11 }, callback: v => v + ' €' },
            grid:  { color: 'rgba(255,255,255,0.05)' },
            border: { display: false },
          }
        }
      }
    });
  }

  // ─ 3. Línea: evolución diaria acumulada ─
  const lineCanvas = document.getElementById('chart-linea');
  const lineEmpty  = document.getElementById('graficas-empty3');

  if (gastos.length === 0) {
    lineCanvas.style.display = 'none';
    lineEmpty.classList.remove('hidden');
  } else {
    lineCanvas.style.display = 'block';
    lineEmpty.classList.add('hidden');

    // Agrupar por día
    const porDia = {};
    gastos.forEach(m => {
      const dia = new Date(m.fecha).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
      porDia[dia] = (porDia[dia] || 0) + m.importe;
    });

    // Ordenar por fecha real
    const diasOrdenados = gastos
      .map(m => ({ key: new Date(m.fecha).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' }), ts: new Date(m.fecha).getTime() }))
      .sort((a, b) => a.ts - b.ts)
      .map(x => x.key)
      .filter((v, i, arr) => arr.indexOf(v) === i);

    let acumulado = 0;
    const lineData = diasOrdenados.map(d => {
      acumulado += porDia[d];
      return Math.round(acumulado * 100) / 100;
    });

    if (chartLinea) chartLinea.destroy();
    chartLinea = new Chart(lineCanvas, {
      type: 'line',
      data: {
        labels: diasOrdenados,
        datasets: [{
          label: 'Gasto acumulado',
          data: lineData,
          borderColor: '#6366f1',
          backgroundColor: 'rgba(99,102,241,0.12)',
          borderWidth: 2.5,
          pointBackgroundColor: '#6366f1',
          pointRadius: 4,
          pointHoverRadius: 6,
          fill: true,
          tension: 0.35,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => ` ${fmt(ctx.raw)} acumulado`
            }
          }
        },
        scales: {
          x: {
            ticks: { color: '#64748b', font: { size: 11 }, maxRotation: 30, autoSkip: true, maxTicksLimit: 8 },
            grid:  { display: false },
            border: { display: false },
          },
          y: {
            ticks: { color: '#64748b', font: { size: 11 }, callback: v => v + ' €' },
            grid:  { color: 'rgba(255,255,255,0.05)' },
            border: { display: false },
          }
        }
      }
    });
  }
}


function openModal(id) {
  document.getElementById(id).classList.remove('hidden');
  document.getElementById(id).style.display = 'flex';
}

function closeModal(id) {
  document.getElementById(id).style.display = 'none';
}

function closeModalOutside(e, id) {
  if (e.target === document.getElementById(id)) closeModal(id);
}

function setTipo(t) {
  tipoActual = t;
  document.getElementById('btn-gasto').classList.toggle('active', t === 'gasto');
  document.getElementById('btn-ingreso').classList.toggle('active', t === 'ingreso');
  document.getElementById('fg-cat').style.display = t === 'gasto' ? '' : 'none';
}

// ── Guardar movimiento ───────────────────────────────────
function guardarMovimiento() {
  const desc    = document.getElementById('inp-desc').value.trim();
  const importe = parseFloat(document.getElementById('inp-imp').value);

  if (!importe || importe <= 0) {
    mostrarToast('Introduce un importe válido', 'info');
    return;
  }

  const mov = {
    id:        Date.now(),
    tipo:      tipoActual,
    categoria: tipoActual === 'gasto' ? document.getElementById('inp-cat').value : null,
    desc:      desc || null,
    importe,
    fecha:     new Date().toISOString(),
  };

  estado.movimientos.push(mov);
  guardarEstado();

  // Limpiar form
  document.getElementById('inp-desc').value = '';
  document.getElementById('inp-imp').value  = '';

  closeModal('modal-add');
  renderAll();

  // Cambiar a tab relevante
  switchTab(tipoActual === 'gasto' ? 'gastos' : 'ingresos');
}

// ── Reset mes ────────────────────────────────────────────
function resetMes() {
  estado = estadoInicial();
  guardarEstado();
  closeModal('modal-reset');
  renderAll();
  mostrarToast('Mes reiniciado', 'info');
}

// ── Tabs ─────────────────────────────────────────────────
function switchTab(nombre) {
  document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
  document.getElementById('tab-' + nombre).classList.add('active');
  document.querySelector(`[data-tab="${nombre}"]`).classList.add('active');
  if (nombre === 'graficas') renderGraficas();
}

// ── Init ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Fecha
  document.getElementById('fecha-hoy').textContent =
    new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });

  // Fecha nómina
  document.getElementById('fecha-nomina').textContent = calcFechaNomina();
  document.getElementById('hdr-nomina').textContent    = calcFechaNomina().split(',')[0] || calcFechaNomina();

  // Pedir permiso notificaciones
  pedirPermisoNotificaciones();

  // Render inicial
  renderAll();

  // Register Service Worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js')
      .then(() => console.log('SW registrado'))
      .catch(err => console.warn('SW error:', err));
  }
});
